# Amini Digital — GitHub Pages website

A responsive one-page website built with plain HTML, CSS, and JavaScript. There is no build process: upload these files to a repository and GitHub Pages can publish it directly.

## Publish on GitHub Pages

1. Create a new GitHub repository and upload `index.html`, `style.css`, `script.js`, and this `README.md` to its root.
2. In the repository, open **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**.
4. Select the `main` branch and the `/ (root)` folder, then save.
5. GitHub will provide the live address after publishing.

## Before launching

The project enquiry form is fully styled and validates all required details, but GitHub Pages is static and cannot send submissions to an inbox alone. Choose a form service, then replace the marked submission section in `script.js` with its endpoint/instructions. Good no-backend options include Formspree, Netlify Forms, and FormSubmit.

Also replace the three portfolio demos, starting package prices, and any brand copy with final content when ready.

## Local preview

Open `index.html` in any web browser. No installation is required.
