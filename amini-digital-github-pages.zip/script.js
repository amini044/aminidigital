/* =============================================================
   AMINI DIGITAL — JAVASCRIPT
   The site works without a framework. Each section below has a
   short explanation so it is easy to learn from and customise.
   ============================================================= */

// 1. Keep the copyright year current automatically.
document.getElementById("current-year").textContent = new Date().getFullYear();

// 2. On small screens, this opens and closes the navigation menu.
const menuButton = document.querySelector(".menu-toggle");
const navigation = document.querySelector(".nav-links");

menuButton.addEventListener("click", () => {
  const menuIsOpen = menuButton.getAttribute("aria-expanded") === "true";
  menuButton.setAttribute("aria-expanded", String(!menuIsOpen));
  menuButton.setAttribute("aria-label", menuIsOpen ? "Open menu" : "Close menu");
  navigation.classList.toggle("is-open", !menuIsOpen);
});

// Close the mobile menu after the visitor selects a link.
navigation.querySelectorAll("a").forEach((link) => {
  link.addEventListener("click", () => {
    menuButton.setAttribute("aria-expanded", "false");
    menuButton.setAttribute("aria-label", "Open menu");
    navigation.classList.remove("is-open");
  });
});

// 3. Add a translucent background to the header after a little scrolling.
const header = document.querySelector(".site-header");
const updateHeader = () => header.classList.toggle("is-scrolled", window.scrollY > 30);
window.addEventListener("scroll", updateHeader, { passive: true });
updateHeader();

// 4. Reveal elements as they enter the screen. IntersectionObserver is efficient
// because the browser tells us when an element becomes visible.
const revealItems = document.querySelectorAll(".reveal");
const revealObserver = new IntersectionObserver(
  (entries, observer) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add("is-visible");
        observer.unobserve(entry.target); // Run the reveal just once.
      }
    });
  },
  { threshold: 0.12 }
);
revealItems.forEach((item) => revealObserver.observe(item));

// 5. Form handling for a static GitHub Pages site.
// GitHub Pages cannot receive form submissions by itself. This version validates
// the form and gives the visitor a clear success message without sending data.
// To make messages arrive in an inbox, connect a service such as Formspree,
// Netlify Forms, or FormSubmit here. See README.md for the exact hand-off point.
const projectForm = document.getElementById("project-form");
const formStatus = document.getElementById("form-status");

projectForm.addEventListener("submit", (event) => {
  event.preventDefault(); // Stay on this page instead of attempting a page reload.

  // Native browser validation highlights the first missing or invalid field.
  if (!projectForm.checkValidity()) {
    projectForm.reportValidity();
    formStatus.textContent = "Please complete the required fields marked above.";
    formStatus.className = "form-status is-error";
    return;
  }

  // This is where a real production request can be sent with fetch().
  // Example: fetch("YOUR_FORM_ENDPOINT", { method: "POST", body: new FormData(projectForm) })
  formStatus.textContent = "Thanks — your project details are ready to send. We’ll be in touch soon.";
  formStatus.className = "form-status is-success";
  projectForm.reset();
});
